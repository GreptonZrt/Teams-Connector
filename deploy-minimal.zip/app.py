"""
Azure Bot Framework Python Bot - Minimális Flask verzió
Teams-hez integrált chat bot - szinkron kód, nincs async
"""

from flask import Flask, request, jsonify
import logging
import os
from dotenv import load_dotenv

# .env betöltése
load_dotenv()

# Logging beállítása
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Flask app inicializálása
app = Flask(__name__)

# Konfiguráció
APP_ID = os.getenv("MicrosoftAppId", "")
APP_PASSWORD = os.getenv("MicrosoftAppPassword", "")

logger.info("Fresh Teams Bot alkalmazás indítása")


@app.route("/api/messages", methods=["POST"])
def messages():
    """
    Main bot message handler - Azure Bot üzeneteit fogadja
    """
    logger.info("Messages endpoint meghívva")
    
    try:
        data = request.get_json()
        
        if not data:
            logger.warning("Üres request body")
            return jsonify({"error": "Empty body"}), 400
        
        logger.info(f"Üzenet érkezett: {data}")
        
        # Üzenet típusának ellenőrzése
        activity_type = data.get("type")
        
        if activity_type == "message":
            # Felhasználó üzenete
            user_message = data.get("text", "")
            logger.info(f"Felhasználó üzenete: {user_message}")
            
            # Bot egyszerű válasza
            bot_response = "Szia! 👋 Ez a Fresh Teams Bot! Az Azure-on futok."
            
            # OK válasz - az Azure Bot Service fogja az üzenetet továbbítani Teams-be
            return jsonify({"status": "ok"}), 200
        
        elif activity_type == "conversationUpdate":
            logger.info("Conversation update érkezett")
            return jsonify({"status": "ok"}), 200
        
        else:
            logger.info(f"Ismeretlen aktivitás típus: {activity_type}")
            return jsonify({"status": "ok"}), 200
    
    except Exception as e:
        logger.error(f"Hiba a messages endpoint-ben: {str(e)}", exc_info=True)
        return jsonify({"error": str(e)}), 500


@app.route("/health", methods=["GET"])
def health_check():
    """Health check endpoint"""
    logger.info("Health check")
    return jsonify({"status": "healthy"}), 200


@app.route("/", methods=["GET"])
def home():
    """Home endpoint"""
    return jsonify({
        "message": "Fresh Teams Bot Azure App Service is running",
        "endpoints": {
            "health": "/health",
            "messages": "/api/messages"
        }
    }), 200


@app.errorhandler(404)
def not_found(error):
    logger.warning(f"404 Not Found: {request.path}")
    return jsonify({"error": "Not found"}), 404


@app.errorhandler(500)
def internal_error(error):
    logger.error(f"500 Internal Server Error: {str(error)}")
    return jsonify({"error": "Internal server error"}), 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    logger.info(f"Bot indítása a 0.0.0.0:{port} porton")
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
    logger.info(f"Bot starting on port {port}")
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
