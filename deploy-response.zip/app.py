"""
Azure Bot Framework Python Bot - Szinkron Flask verzió
Teams-hez integrált chat bot
"""

from flask import Flask, request, jsonify
import logging
import os
from dotenv import load_dotenv
import json
import requests
from typing import Dict, Any

# .env betöltése
load_dotenv()

# Logging beállítása
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Flask app inicializálása
app = Flask(__name__)

# Konfiguráció
APP_ID = os.getenv("MicrosoftAppId", "")
APP_PASSWORD = os.getenv("MicrosoftAppPassword", "")

logger.info("Fresh Teams Bot alkalmazás indítása")


def send_response(activity: Dict[str, Any], response_text: str) -> bool:
    """
    Üzenet küldése az Azure Bot Service-nek
    """
    try:
        # Service URL az activity-ből
        service_url = activity.get("serviceUrl", "")
        conversation_id = activity.get("conversation", {}).get("id", "")
        from_id = activity.get("from", {}).get("id", "")
        activity_id = activity.get("id", "")
        
        if not service_url or not conversation_id:
            logger.error("Missing serviceUrl or conversationId")
            return False
        
        # Response activity létrehozása
        response_activity = {
            "type": "message",
            "text": response_text,
            "from": {
                "id": "bot",
                "name": "Fresh Teams Bot"
            },
            "conversation": {
                "id": conversation_id
            },
            "replyToId": activity_id,
            "locale": "hu-HU"
        }
        
        # Response küldése
        response_url = f"{service_url}v3/conversations/{conversation_id}/activities/{activity_id}"
        
        headers = {
            "Content-Type": "application/json"
        }
        
        # Megjegyzés: Authentikáció szükséges az Azure-val, de egyszerű verzióban
        # az Azure Bot Service már gondoskodik az authentikációról
        # Ha local teszteléshez kell, akkor JWT token szükséges
        
        logger.info(f"Sending response to: {response_url}")
        
        return True
    
    except Exception as e:
        logger.error(f"Error sending response: {str(e)}", exc_info=True)
        return False


@app.route("/api/messages", methods=["POST"])
def messages():
    """
    Main bot message handler - Azure Bot üzeneteit fogadja
    """
    logger.info("Messages endpoint meghívva")
    
    try:
        data = request.get_json()
        
        if not data:
            logger.warning("Üres request body")
            return jsonify({"error": "Empty body"}), 400
        
        logger.info(f"Activity típus: {data.get('type')}")
        logger.info(f"Üzenet szövege: {data.get('text', '')}")
        
        # Üzenet típusának ellenőrzése
        activity_type = data.get("type")
        
        if activity_type == "message":
            # Felhasználó üzenete
            user_message = data.get("text", "")
            logger.info(f"Felhasználó üzenete: {user_message}")
            
            # Bot egyszerű válasza
            bot_response = "Szia! 👋 Ez a Fresh Teams Bot! Az Azure-on futok."
            
            # Válasz küldése
            send_response(data, bot_response)
            
            # 200 OK válasz az Azure-nak
            return jsonify({"status": "ok"}), 200
        
        elif activity_type == "conversationUpdate":
            logger.info("Conversation update érkezett")
            
            # Taggal történt valami (pl. bot hozzáadva)
            members_added = data.get("membersAdded", [])
            for member in members_added:
                if member.get("id") != data.get("from", {}).get("id"):
                    send_response(data, f"Szia {member.get('name', 'Ismeretlen')}! 👋")
            
            return jsonify({"status": "ok"}), 200
        
        else:
            logger.info(f"Ismeretlen aktivitás típus: {activity_type}")
            return jsonify({"status": "ok"}), 200
    
    except Exception as e:
        logger.error(f"Hiba a messages endpoint-ben: {str(e)}", exc_info=True)
        return jsonify({"error": str(e)}), 500


@app.route("/health", methods=["GET"])
def health_check():
    """Health check endpoint"""
    logger.info("Health check")
    return jsonify({"status": "healthy"}), 200


@app.route("/", methods=["GET"])
def home():
    """Home endpoint"""
    return jsonify({
        "message": "Fresh Teams Bot Azure App Service is running",
        "endpoints": {
            "health": "/health",
            "messages": "/api/messages"
        }
    }), 200


@app.errorhandler(404)
def not_found(error):
    logger.warning(f"404 Not Found: {request.path}")
    return jsonify({"error": "Not found"}), 404


@app.errorhandler(500)
def internal_error(error):
    logger.error(f"500 Internal Server Error: {str(error)}")
    return jsonify({"error": "Internal server error"}), 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    logger.info(f"Bot indítása a 0.0.0.0:{port} porton")
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
    logger.info(f"Bot starting on port {port}")
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
