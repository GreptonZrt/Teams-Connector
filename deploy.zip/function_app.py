import azure.functions as func
import json
import logging
import os
from botbuilder.core import BotFrameworkAdapter, BotFrameworkAdapterSettings, TurnContext
from botbuilder.schema import Activity
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = func.FunctionApp()

# Bot Framework Adapter Settings from environment
APP_ID = os.getenv("MicrosoftAppId", "")
APP_PASSWORD = os.getenv("MicrosoftAppPassword", "")

logging.info(f'Bot initialized with App ID: {APP_ID[:8]}...')

SETTINGS = BotFrameworkAdapterSettings(APP_ID, APP_PASSWORD)
ADAPTER = BotFrameworkAdapter(SETTINGS)

async def on_message_activity(turn_context: TurnContext):
    """Handle incoming messages from Teams"""
    user_message = turn_context.activity.text
    logging.info(f'Received message from Teams: {user_message}')
    
    # Echo bot logic
    reply = f'Echo: {user_message} (Szia! Ez a Fresh Teams Bot!)'
    await turn_context.send_activity(reply)

@app.route(route='messages', auth_level=func.AuthLevel.ANONYMOUS, methods=['POST'])
async def messages(req: func.HttpRequest) -> func.HttpResponse:
    """Bot Framework messages endpoint for Teams"""
    
    logging.info('Bot message received from Teams')
    
    if "application/json" in req.headers.get("Content-Type", ""):
        body = req.get_json()
    else:
        return func.HttpResponse(status_code=415)

    activity = Activity().deserialize(body)
    auth_header = req.headers.get("Authorization", "")

    try:
        response = await ADAPTER.process_activity(activity, auth_header, on_message_activity)
        if response:
            return func.HttpResponse(json.dumps(response.body), status_code=response.status)
        return func.HttpResponse(status_code=201)
    except Exception as e:
        logging.error(f'Error processing activity: {str(e)}')
        return func.HttpResponse(json.dumps({'error': str(e)}), status_code=500)

@app.route(route='chat', auth_level=func.AuthLevel.ANONYMOUS, methods=['POST'])
def chat(req: func.HttpRequest) -> func.HttpResponse:
    """Legacy chat API - for direct HTTP testing"""

    logging.info('Chat request received')

    try:
        req_body = req.get_json()
        user_message = req_body.get('message', '')

        logging.info(f'User message: {user_message}')

        # Bot egyszerű válasza
        bot_reply = f'Echo: {user_message} (Szia! Ez a Fresh Teams Bot!)'

        response_data = {
            'success': True,
            'message': user_message,
            'reply': bot_reply,
            'timestamp': str(__import__('datetime').datetime.now())
        }

        return func.HttpResponse(
            json.dumps(response_data),
            status_code=200,
            mimetype='application/json'
        )

    except ValueError as e:
        return func.HttpResponse(
            json.dumps({'error': 'Invalid JSON', 'details': str(e)}),
            status_code=400
        )
    except Exception as e:
        logging.error(f'Error: {str(e)}')
        return func.HttpResponse(
            json.dumps({'error': str(e)}),
            status_code=500
        )

@app.route(route='health', auth_level=func.AuthLevel.ANONYMOUS, methods=['GET'])
def health_check(req: func.HttpRequest) -> func.HttpResponse:
    """Health check endpoint"""
    return func.HttpResponse(
        json.dumps({'status': 'healthy', 'service': 'Fresh Teams Bot'}),
        status_code=200,
        mimetype='application/json'
    )
