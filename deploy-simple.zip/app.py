"""
Azure Bot Framework Python Bot - Egyszerű Flask verzió
Teams-hez integrált chat bot
"""

from flask import Flask, request, jsonify
import requests
import logging
import os
from dotenv import load_dotenv

# .env betöltése
load_dotenv()

# Logging beállítása
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Flask app inicializálása
app = Flask(__name__)

# Konfiguráció
APP_ID = os.getenv("MicrosoftAppId", "")
APP_PASSWORD = os.getenv("MicrosoftAppPassword", "")


@app.route("/api/messages", methods=["POST"])
def messages():
    """
    Main bot message handler - Azure Bot üzeneteit fogadja
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({"error": "Empty body"}), 400
        
        # Üzenet információk
        activity_type = data.get("type")
        
        if activity_type == "message":
            # Felhasználó üzenete
            user_message = data.get("text", "")
            conversation_id = data.get("conversation", {}).get("id", "")
            from_id = data.get("from", {}).get("id", "")
            
            logger.info(f"Üzenet érkezett: {user_message}")
            
            # Bot válasza
            bot_response = f"Echo: {user_message}"
            
            # Válasz küldése az Azure Bot-nak
            response_data = {
                "type": "message",
                "text": bot_response,
                "conversation": {"id": conversation_id},
                "from": {"id": "bot", "name": "Fresh Teams Bot"},
                "recipient": {"id": from_id},
                "replyToId": data.get("id")
            }
            
            # Az Azure Bot Service-hez küldés (ha szükséges)
            # Erre az Azure Bot Service gondol, de mi egyszerűen válaszoljuk meg az üzenetet
            
            return jsonify(response_data), 200
        
        elif activity_type == "conversationUpdate":
            # Új tag csatlakozásakor
            logger.info("Conversation update")
            return jsonify({"status": "ok"}), 200
        
        else:
            logger.info(f"Unknown activity type: {activity_type}")
            return jsonify({"status": "ok"}), 200
    
    except Exception as e:
        logger.error(f"Error in messages endpoint: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route("/health", methods=["GET"])
def health_check():
    """Health check endpoint"""
    return jsonify({"status": "healthy"}), 200


@app.route("/", methods=["GET"])
def home():
    """Home endpoint"""
    return jsonify({
        "message": "Fresh Teams Bot Azure App Service is running",
        "endpoints": {
            "health": "/health",
            "messages": "/api/messages"
        }
    }), 200


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    logger.info(f"Bot starting on port {port}")
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
