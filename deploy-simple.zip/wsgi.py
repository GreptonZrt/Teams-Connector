"""
WSGI alkalmazás az Azure-hoz
"""

from aiohttp import web
from app import init_app

# Inicializálj az aiohttp app-ot
app = init_app()

# Azure számára szükséges alkalmazás-objektum
wsgi_app = app
