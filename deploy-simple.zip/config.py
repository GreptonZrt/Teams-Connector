"""
Bot konfigurációs fájl
"""

import os
from dotenv import load_dotenv

# .env fájl betöltése
load_dotenv()

class DefaultConfig:
    """Konfigurációs osztály"""
    
    # Microsoft App ID és jelszó (később töltsd ki az Azure Bot-ból)
    APP_ID = os.getenv("MicrosoftAppId", "")
    APP_PASSWORD = os.getenv("MicrosoftAppPassword", "")
    
    # Azure Bot beállítások
    APP_TYPE = os.getenv("AppType", "MultiTenant")
    AUTHORITY = os.getenv("Authority", "https://login.microsoftonline.com")
    VALID_AUDIENCES = [APP_ID]
    
    # Port és host
    PORT = int(os.getenv("PORT", "3978"))
    WEBSITE_HOSTNAME = os.getenv("WEBSITE_HOSTNAME", "localhost:3978")
