"""
Bot osztály - a bot logika itt van
"""

from botbuilder.core import ActivityHandler, TurnContext
from botbuilder.schema import ChannelAccount

class MyBot(ActivityHandler):
    """
    A bot logikáját tartalmazó osztály
    """

    async def on_message_activity(self, turn_context: TurnContext):
        """
        Üzenet érkeztésekor hívódik meg
        """
        # Felhasználó üzenete
        user_message = turn_context.activity.text
        print(f"Felhasználó üzenete: {user_message}")

        # Egyszerű válasz
        response_text = "Szia! 👋 Ezt a botot Azure-on futtatjuk, és Teams-ben elérhető lesz."
        
        # Válasz küldése
        await turn_context.send_activity(response_text)

    async def on_members_added_activity(
        self,
        members_added: ChannelAccount,
        turn_context: TurnContext
    ):
        """
        Új tag csatlakozásakor hívódik meg
        """
        for member_added in members_added:
            if member_added.id != turn_context.activity.recipient.id:
                await turn_context.send_activity(
                    f"Szia {member_added.name}! 👋 Én a Teams Bot vagyok. Bármit írj nekem és segíteni fogok!"
                )
